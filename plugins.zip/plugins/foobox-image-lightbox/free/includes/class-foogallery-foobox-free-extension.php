<?php
if ( !class_exists( 'FooGallery_FooBox_Free_Extension' ) ) {

	class FooGallery_FooBox_Free_Extension {
		//this was removed as this is now part of FooGallery
	}
}